智能彩票号码分析器 V4（Android Studio 项目源码）

这一版将 V3 网页应用封装为原生 Android WebView 应用工程，目标是生成 APK。
功能：
- 双色球 / 大乐透 / 七乐彩选号
- 热门、冷门、均衡、随机模式
- 奇偶、大小、和值、跨度、连号、最近一期重号筛选
- 导入历史开奖 CSV/TXT、统计频率和遗漏、导出数据
- 本地 localStorage 保存选号和历史记录
- 支持 Android 文件选择器，用于选择导入文件
- 网页链接交给系统浏览器打开

重要限制：
- 这是 Android Studio 项目源码，不是已经编译并真机测试的 APK。
- 当前环境未运行 Android SDK/Gradle 构建，因此没有声称 APK 已经成功编译。
- 自动联网同步仍依赖用户配置的可用 JSON API；尚未验证某个 API 能完整覆盖三个彩种历年数据。
- 历史分析不能可靠预测开奖，也不提高公平开奖中单注理论中奖概率。

如何构建 APK：
1. 在电脑安装 Android Studio（建议稳定版）及 Android SDK Platform 35、JDK 17。
2. Android Studio 选择 Open，打开本文件夹 LotteryAnalyzerV4。
3. 等待 Gradle Sync 完成；如提示升级 Gradle/插件，先使用项目配置版本或按 Android Studio 提示升级。
4. 菜单 Build -> Build Bundle(s) / APK(s) -> Build APK(s)。
5. 成功后 APK 通常位于 app/build/outputs/apk/debug/app-debug.apk。
6. 将 APK 传到手机安装。首次安装时需允许该来源安装应用。

如果只用手机没有电脑：
- 可先使用 V3/V4 的 index.html 网页版本。
- 原生 APK 的编译需要 Android 构建环境；本 ZIP 不含预编译 APK。

数据导入格式推荐：
双色球：期号,日期,红1,红2,红3,红4,红5,红6,蓝
大乐透：期号,日期,前1,前2,前3,前4,前5,后1,后2
七乐彩：期号,日期,基本1,基本2,基本3,基本4,基本5,基本6,基本7

手机无电脑：云端编译 APK（新增）
本项目新增 .github/workflows/build-apk.yml，可让 GitHub 云端编译调试版 APK，不需要在手机本地安装 Android Studio。
1. 在浏览器打开 GitHub 并登录，创建一个新的空仓库（建议 Public 或 Private 均可；不要勾选自动创建 README）。
2. 将本 ZIP 解压后，把项目里的所有文件和文件夹上传到仓库根目录；必须包括 .github/workflows/build-apk.yml。若手机页面看不到以点开头的 .github 文件夹，请在 GitHub 网页开启“桌面版网站”后操作，或用支持显示隐藏文件的文件管理器。
3. 上传并提交到 main 分支后，打开仓库的 Actions 页面，选择 “Build Android APK”，点击 Run workflow（如果 push 自动触发了，也可直接打开正在运行的任务）。
4. 等待任务显示绿色成功，再进入该次运行页面底部的 Artifacts，下载 lottery-analyzer-debug-apk.zip。
5. 在手机上解压，找到 app-debug.apk，点击安装。Android 可能会要求允许浏览器或文件管理器“安装未知应用”。只安装自己仓库构建出的文件。
6. 这是调试签名 APK，适合个人测试，不是 Play 商店发布包。云端编译是否成功仍需由 GitHub Actions 实际运行确认；如果失败，打开构建日志，把报错内容发来即可继续修复。

注意：GitHub 账户和仓库需要由用户自己创建和操作；我无法替用户登录或代为上传仓库。云端构建仅解决编译环境问题，不会自动补齐或验证彩票历史开奖数据接口。
